#!/usr/bin/env bash
rm dist/* || true
gradle -PGHIDRA_INSTALL_DIR="/media/matheus/Data/ghidra/"
cp dist/ghidra_9.1.2_PUBLIC* $HOME
